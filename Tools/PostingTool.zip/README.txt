Posting Tool 6.x


Requirements:
=============
NET 4.7.2
Oracle DB access
SQLite

To decision a deal:
===================
1. Choose Environment
2. Type in deal #, and click -> to retrieve deal info.
3. Select a decision from drop down
4. Click POST button

Decision Parameters:
- Normally NO need to update these parameters
- If "Enable Parameters" is unchecked, parameters will be ignored

To create a DMS deal:
=====================
1. Input Basic info about the deal to be created
2. Type in Dealer ID, and click -> to retrieve DMS info
3. Select a XML from drop down
4. Click POST button
If successful, a message will pop up with the deal number already created.

To create a Lead:
=================
1. Choose from "JSON used"
2. Choose an Action from the list
- Create a New Lead
- Update an existing Lead
- Validate a Lead
3. Click POST button

To decision deals in batch mode:
================================
1. Go to Batch tab
2. Type in, or Paste DealNo:Status pairs separated by space
3. Click POST button

To edit custom notes or decision xml
====================================
1. Load custom notes or decision xml
2. Click Edit button
3. Make your changes on notes/XML UI
4. Click Apply button
5. Click Post button

To import custom xml from old posting tool
==========================================
1. Main Menu, click File
2. Click Import
3. On Import UI, import your xml

To load built-in decision xml from posting tool
===============================================
1. Main > My XML, type lender name, then select built-in decision xml
2. Click Loan button
3. Click Edit button to update deal parameters
4. Click Apply button
5. Click Post button

============================
LIST OF SUPPORTED LENDERS   
============================

1. ALPHERA (ONLY working with DR, DI, and BK)
2. ATB
3. AutoCapital
4. BMO
5. BNC
6. UNI Financial (CAISSE)
7. CARFINCO (Santander)
8. CIBC
9. CRC (Cars On Credit) >> AXIS
10. CTL (CTL/iA Auto Finance)
11. CUDealerFinanceCorp
12. DESJARDINS
13. GBC
14. GGR
15. GMF Lease
16. GMF Loan
17. HMF/KMF
18. NISSAN
19. PORSCHE
20. RBC
21. RIFCO
22. RTP (Return to Prime)
23. SCOTIA
24. SDA
25. SERVUS
26. Source One
27. TDAF
28. TRAVELERS
29. TRICOR
30. EdenPark
31. Go Auto Finance
32. AutoNum
33. Norther Credit Union (NCU)
34. BMW
35. LCR
36. PREFERA
37. SFQ
38. DSZ
39. DCT
40. ICE
41. Carma
42. Desjardins Commercial
43. Connect First Credit Union
44. Caisse Populaire Alliance limitée
45. Northlake Financial ULC
46. CU Auto Finance
47. Prairie Centre Credit Union
48. CreditMaxx Financing and Leasing Inc.
49. Audi Finance for Ducati
50. Credit River Capital Inc.
51. OCM Auto Financing Group Ltd.
52. Summit Finance
53. Drive Finance (DFW)
54. LB SE Test (MTB)
55. TEST AAA Lender EN (AAA)
56. TEST EEE Lender EN (EEE)
57. MBS (Mercedes)
58. SA Financial (CVZ)
59. ESG
60. WSLease
61. DUCA
62. AutoOne
63. [BLANK]

================
Thanks for the help and support from all of you!

Quinn
2025.12.16