# Changelog
All notable changes to this tool are here.


## [6.4.2.0] - 2025-08-09

### Fixed
- Fixed error in TD Pre-Approval decision

---------------------------------------------------------

## [6.4.1.0] - 2025-07-26

### Added
- DUCA Financial decision support

### Modified
- Refactored method to address potential issue with custom XML loading

---------------------------------------------------------

## [6.4.0.0] - 2025-07-18

### Added
- TD Lease decision and Notes support
- Optional logging based on appsettings.json configuration

---------------------------------------------------------

## [6.3.0.0] - 2025-06-09

### Fixed
- Fixed first-time database connection issue

### Added
- Dark Mode theme

---------------------------------------------------------

## [6.2.1.0] - 2025-02-21

### Modified
- UI Update: Introduced the Lender Reference Number (LRN#) in Deal Info 
- Enhancement: Incorporated the Lender Reference Number into the RBC decision XML

---------------------------------------------------------

## [6.2.0.0] - 2025-02-21

### Modified
- Removed Access tab
- Refactored solution to improve UI responsiveness
- Implemented changes to allow new stage decisioning
- Moved DRS/DMS to options UI and disabled by default

---------------------------------------------------------

## [6.1.1.0] - 2024-11-24

### Modified
- Update MBFS decision XML
- Silently handle exceptions when saving settings on desktop tool close

---------------------------------------------------------

## [6.1.0.0] - 2024-11-24

### Fixed
- Resolve the SDA decision issue in custom XML due to the default tier value

### Added
- WS Lease decision support(DTMM-3385)

---------------------------------------------------------

## [6.0.2.0] - 2024-09-18

### Modified
- Update stage instance IP address (100.69.133.180)

---------------------------------------------------------

## [6.0.1.0] - 2024-09-03

### Added
- First Ontario with DR/DI/PP/EX decision (DTF-7201)

---------------------------------------------------------

## [6.0.0.0] - 2024-09-02

### Added
- Support Pre-Qualification as a new product for TD

---------------------------------------------------------

## [5.9.9.0] - 2024-07-18

### Modified
- Updated decision URL for DR environment

---------------------------------------------------------

## [5.9.8.0] - 2024-05-31

### Added
- Added Deal Decision Support for DR Environment

### Modified
- Resolved Option Setting Update Issue
- Updated Application Icon

---------------------------------------------------------

## [5.9.7.0] - 2024-04-02

### Modified
-  Updated decision url of GMF Lease

---------------------------------------------------------

## [5.9.6.0] - 2023-11-27

### Added
-  New Access Tab
-  IP update fow for access to Jenkins and Report Portal

---------------------------------------------------------

## [5.9.5.0] - 2023-11-27

### Added
-  Revised IP address for staging environment
-  Introduced checkboxes on the options UI to bypass Endpoint and HTTP Post Errors when selected

---------------------------------------------------------

## [5.9.4.1] - 2023-11-7

### Added
-  Support lender NFY (new instance of NorthLake)

---------------------------------------------------------

## [5.9.4.0] - 2023-09-19

### Modified
-  Allow deal decision to proceed despite endpoint error
-  Allow currency value in TAF field in Edit XML UI 

---------------------------------------------------------

## [5.9.3.1] - 2023-07-04

### Modified
-  MBS lender (Mercedes) decision json bodId format update:
{applicationProfileId}{productCode} -> {applicationProfileId}-{productCode}

---------------------------------------------------------

## [5.9.3.0] - 2023-07-02

### Modified
-  MBS lender (Mercedes) decision JSON change on decisionComments

### Added
-  Support ESG lender decision

---------------------------------------------------------

## [5.9.2.0] - 2023-06-22

### Modified
-  MBS lender (Mercedes) decision using JSON

---------------------------------------------------------

## [5.9.1.0] - 2023-06-15

### Added
-  Support SA Financial lender (CVZ)

---------------------------------------------------------

## [5.9.0.0] - 2023-04-24

### Added
-  Support MBS lender (Mercedes)

---------------------------------------------------------

## [5.8.4.0] - 2023-03-07

### Added
-  Support additional 3 NLC Lenders:
* MTB - LB SE Test Lender
* AAA - TEST AAA Lender EN
* EEE - TEST EEE Lender EN

- Verify the endpoint URL before attempting to post the decision XML

---------------------------------------------------------

## [5.8.3.0] - 2023-02-27

### Added
-  Support NLC lender DFW (Drive Finance)

---------------------------------------------------------

## [5.8.2.0] - 2022-12-11

### Updated
-  HMF decision xml with new tag AMTerm (Loan Only)

---------------------------------------------------------

## [5.8.1.0] - 2022-11-16

### Fixed
-  DMS import getting DB error

---------------------------------------------------------

## [5.8.0.0] - 2022-11-13

### Updated
-  HMF/HMF decision XML to include AmTerm (Amortization)
-  AWS ExternalComm base url (UAT AWS cutover)
-  QA On Prem decision decommissioned
-  Fixed UI refresh issue on status update

---------------------------------------------------------

## [5.7.3.0] - 2022-10-28

### Added
-  Added CA, CP status to Nissan

---------------------------------------------------------

## [5.7.2.0] - 2022-09-21

### Updated
-  AWS DB hostname change

---------------------------------------------------------

## [5.7.2.0] - 2022-09-19

### Added
- Support additional 13 NLC Lenders:
* Carma
* Desjardins Commercial
* Connect First Credit Union
* Caisse Populaire Alliance limitée
* Northlake Financial ULC
* CU Auto Finance
* Prairie Centre Credit Union
* CreditMaxx Financing and Leasing Inc.
* Audi Finance for Ducati
* Credit River Capital Inc.
* OCM Auto Financing Group Ltd.
* Summit Finance
* AXIS
 
---------------------------------------------------------

## [5.7.0.0] - 2022-06-15

### Added
-  Support AWS QA deal decisioning

---------------------------------------------------------

## [5.6.8.0] - 2022-04-15

### Enhanced
- UI enhancement
- Update CIBC decision url

### Added
- show use parameters status

---------------------------------------------------------

## [5.6.7.0] - 2022-04-15

### Added
- BMW Esign decision xml as custom xml

---------------------------------------------------------

## [5.6.6.0] - 2022-04-03

### Fixed
- SDA 5 Star+ issue in decision xml

---------------------------------------------------------

## [5.6.5.0] - 2022-03-14

### Fixed
- Wrong built-in Scotia xml
- Issue in parsing Nissan xml

### Enhanced
- By storing DR IP into config file

---------------------------------------------------------

## [5.6.4.0] - 2022-03-10

### Added
- Support for SDA 5 Star+ and 6 Star decisioning

---------------------------------------------------------

## [5.6.3.0] - 2022-03-09

### Fixed
- Issue with AWS DEV deal decisioning

---------------------------------------------------------

## [5.6.2.0] - 2022-02-04

### Added
- NLC lender iceberg

---------------------------------------------------------

## [5.6.1.0] - 2022-02-04

### Fixed
- Fixed issue when decisioning deals from deal copy

---------------------------------------------------------

## [5.6.0.0] - 2022-02-01

### Enhanced
- Disabled PROD decision

### Fixed
- GMF Loan decision issue
- BMW xml editing issue
- SDA tier decision issue

### Added
- Main tab > My XML : User can type and load built-in decision XML
- Added additional tiers to SDA and RBC
- Added CP, DI and DR status to RBC

---------------------------------------------------------

## [5.5.2.0] - 2021-09-26

### Enhanced
- Updated DESJ decision
- Added DESJ notes xml
- Database connection

### Fixed
- Dev decision issue

---------------------------------------------------------

## [5.5.0.0] - 2021-09-07

### Added
- Query OEM program vin numbers using custom xml

### Enhanced
- Database connection

---------------------------------------------------------

## [5.4.0.0] - 2021-07-01

### Added
- Added DCT decision

### Enhanced
- XML loading experience on UI

---------------------------------------------------------

## [5.3.2.0] - 2021-06-21

### Added
- Added DSZ decision

### Enhanced
- XML loading experience on UI

---------------------------------------------------------

## [5.3.0.0] - 2021-06-17

### Added
- Added Prime and Tier flows to Carfinco
- Minor UI updates

---------------------------------------------------------

## [5.2.8.0] - 2021-04-21

### Fixed
- Error when editing sda decision xml

---------------------------------------------------------

## [5.2.6.0] - 2021-04-12

### Fixed
- Error when editing scotia decision xml
- Bmo tier mapping issue in data file

---------------------------------------------------------

## [5.2.4.0] - 2021-02-13

### Modified
- Updated decision xml and url for FOC

---------------------------------------------------------

## [5.2.2.0] - 2021-01-21

### Fixed
- HMF/HMF XML parsing issue

### Modified
- Change GMF Loan NOT to use form post
- Year update in BMW xml
- Update BMO with new xml

---------------------------------------------------------

## [5.2.0.0] - 2020-11-23

### Added
- Added First Ontario

### Modified
- URL update for GBC

---------------------------------------------------------

## [5.1.0.0] - 2020-09-20

### Added
- Import custom xml from old posting tool
> Main Menu > Click File > Import > Continue on Import UI

---------------------------------------------------------

## [5.0.0.0] - 2020-09-16

### Modified
- UI changes
> Reduce UI height to fit in smaller screen
> Can launch without DB access (to allow post custom xml)
> Changes for Carfinco Lender 

### Added
- Allow edit custom notes xml
- Allow edit custom decison xml
- Added extra check on DR/PROD environment, if DR or PROD is selected
- Added decision xml for HCC

---------------------------------------------------------


## [4.3.1.0] - 2020-04-12

### Modified
- Minor changes

---------------------------------------------------------

## [4.3.0.0] - 2020-04-07

### Added
- Support for lender SFQ decisioning

---------------------------------------------------------

## [4.2.0.0] - 2020-01-31

### Modified
- Updated header authentication from HMAC to x-token

---------------------------------------------------------

## [4.1.1.0] - 2020-01-29

### Added
- AD, BK, DI and DR to TDAF decision

---------------------------------------------------------

## [4.1.0.0] - 2020-01-28

### Added
- ExternalCommTDC HMAC Authentication support

---------------------------------------------------------

## [4.0.0.4] - 2020-01-28

### Fixed
- Update RBC decision url to use only inovatec

---------------------------------------------------------

## [4.0.0.2] - 2020-01-04

### Fixed
- Post button will be hidden on smaller laptops

### Added
- Added shortcut (Alt + P) to Post button

---------------------------------------------------------

## [4.0.0.1] - 2019-10-24
### Fixed
- Issue with posting url in DEV environment

---------------------------------------------------------

## [4.0.0.0] - 2019-10-16
### Added
- Allow decisions to be posted in batch mode
1. Decision multiple deals with one click 
(e.g., Go to Batch tab > Type in "10411308:DE 10451287" > Click Post. By default it's AP if no status is provided)

- Allow users to Store their own XMLs for later usage (with the help of embedded SQLite DB)
(e.g., To save current XML, specify a name in "My XML", click Save; To Load a XML, select a name from dropdown list, click Load)

- Recent deal list history (from Main tab only)
1. By default, the History menu will keep max 2 days, or 20 items
2. To configure, Go to File > Options > Specify max days or records

- Pre-stored some notes XMLs in the “My XML” drop down

- Added to right-click menu of current XML
1. Send to mail recipient
2. Open in Notepad
3. Save As (to file)


### Modified
- Host name updated due to Oracle 12c Database Migration (Dev)

---------------------------------------------------------

## [3.7.2.0] - 2019-06-11

### Added
- Enable RBC non prime decisioning

---------------------------------------------------------

## [3.7.1.0] - 2019-04-26

### Fixed
- Pre-approval deals decisioning not working

---------------------------------------------------------

## [3.7.0.2] - 2019-04-05

### Added
- Added BMW to DMS import

### Modified
- Show lenders in sorted order for DMS import
- DRS Json updated

### Fixed
- Some lenders with 3rd Party Interfaces activated, but fails to populate DMS info

---------------------------------------------------------

## [3.7.0.0] - 2019-03-01

### Modified
- Updated BMW decision XML
- Make TLS 1.2 as default to avoid connection errors
- Added more decision statuses for GMF Loan

### Added
- Added a checkedbox for posting custom decision XML

---------------------------------------------------------

## [3.6.6.0] - 2018-12-05

### Fixed
- RBC decision XML not updated with term and amortization decision parameters
### Modified
- Notification message

---------------------------------------------------------

## [3.6.4.0] - 2018-09-28

### Fixed
- DMS customized XML does not work
 (Check "Use Customized XML", and post DMS xml as it is)

---------------------------------------------------------

## [3.6.3.1] - 2018-09-17

### Fixed
- Non-Auto deals could not be decisioned

--------------------------------------------------------- 

## [3.6.3.0] - 2018-09-07
### Added
- Add NLC lender LCR

--------------------------------------------------------- 

## [3.6.2.0] - 2018-08-28

### Modified
- Switch the URLs between Originate and Inovatec RBC deals

--------------------------------------------------------- 

## [3.6.1.0] - 2018-08-02

### Fixed
- Nissan commercial lease with co-applicant decision issues

### Added
- Added support for BMW deal decisions
- Added status BK/DI/DR to HMF/KMF

--------------------------------------------------------- 

## [3.5.3.0] - 2018-06-12

### Fixed
- RBC non-auto deal decision issues

### Modified
- Added checkbox to allow using customized DMS XML for posting

---------------------------------------------------------

## [3.5.2.0] - 2018-05-31

### Modified
- Support RBC deals with both Inovatec and Origenate backends

---------------------------------------------------------

## [3.5.0.0] - 2018-05-25

### Modified
- Show deal status icon instead of status text. It's now more eye-friendly :)
- Enable GMF Loan deal decision for Bi-Weekly (12 - monthly, 26 - Bi-Weekly)

---------------------------------------------------------

## [3.4.2.1] - 2018-04-24

### Modified
- Updated the default value of Rifco XML <tier> from N-A to 1, due to issue with Pre-approval deals

---------------------------------------------------------

## [3.4.2.0] - 2018-03-27

### Fixed
- Approved GMF Loan deals require resubmissions, and cannot print out docs
- If values in decision parameters tab are modified, decision XML is not updated accordingly

---------------------------------------------------------

## [3.4.0.1] - 2018-03-02

### Fixed
- Fixed XML for NCU to work with all assets

---------------------------------------------------------

## [3.4.0.0] - 2018-03-01

### Modified
- Improved auto complete on find box
- Allow user to posting customized XML (like old posting tool)

### Added
- Implemented NLC lender: Norther Credit Union

----------------------------------------------------------

## [3.2.2.2] - 2018-02-17

### Modified
- Improved right click menu on decision XML field

### Added 
- Support deals with same lender name but different product (Lease, Loan)

----------------------------------------------------------

## [3.0.2.2] - 2018-02-03

### Modified
- Caisse Pop changing to UNI financial

----------------------------------------------------------

## [3.0.1.2] - 2018-01-28

### Added
- A checkbox in Parameters tab. If unchecked, the parameters on this tab will be ignored

----------------------------------------------------------

## [3.0.0.2] - 2018-01-24

### Fixed
- Tier lenders (SDA, TDAF) decision fail

----------------------------------------------------------

## [3.0.0.0] - 2018-01-14

### Added
-  DRS support: Create/Modify/validate Leads in JSON
-  Show DealerId and DBA name (tooltip) in Deal info

### Modified
- Allow Received Message to be copied
- Version update from 2.0 to 3.0

----------------------------------------------------------

## [2.2.1.2] - 2017-12-20

### Fixed
- Added DEV DB access

### Added
- Once Deal#/Dealer ID is entered, press ENTER key to start a DB query
